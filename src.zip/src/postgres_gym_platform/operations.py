from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.parse import quote, urlsplit

from . import __version__


def checked(command: list[str], *, cwd: Path | None = None):
    result = subprocess.run(command, cwd=cwd, stdout=sys.stderr, check=False)
    if result.returncode:
        raise ValueError(f"Command failed with exit code {result.returncode}: {command[0]}")


def templates() -> Path:
    source = Path(__file__).resolve().parents[2] / "deploy"
    return source if source.is_dir() else Path(__file__).parent / "templates" / "deploy"


def initialize_instance(directory: Path, origin: str, open_registration: bool = False) -> dict:
    """Create an isolated platform instance and its secrets."""
    origin_parts = urlsplit(origin)
    if (origin_parts.scheme not in {"http", "https"} or not origin_parts.hostname
            or origin_parts.path not in {"", "/"} or origin_parts.username
            or origin_parts.password or origin_parts.query or origin_parts.fragment
            or "\n" in origin):
        raise ValueError("--origin must be an HTTP(S) origin without a path or credentials")
    directory = directory.expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    if any(directory.iterdir()):
        raise ValueError("An instance already exists in this directory")
    shutil.copy2(templates() / "platform" / "compose.yaml", directory / "compose.yaml")
    for name in ("secrets", "data", "worker-data", "gpu-worker-data"):
        (directory / name).mkdir(mode=0o700)
    for name, value in (("master.key", base64.urlsafe_b64encode(os.urandom(32))),
                        ("worker-token", secrets.token_urlsafe(32).encode()),
                        ("registration-token", secrets.token_urlsafe(24).encode())):
        path = directory / "secrets" / name
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as output:
            output.write(value)
    uid = os.getuid() if hasattr(os, "getuid") else 1000
    gid = os.getgid() if hasattr(os, "getgid") else 1000
    socket_path = Path("/var/run/docker.sock")
    docker_gid = socket_path.stat().st_gid if socket_path.exists() else 0
    config = (f"PG_GYM_DOCKER_GID={docker_gid}\nPG_GYM_VERSION={__version__}\n"
              f"PG_GYM_ORIGIN={origin}\nPG_GYM_OPEN_REGISTRATION={'1' if open_registration else '0'}\n"
              f"PG_GYM_SECURE_COOKIE={'1' if origin.startswith('https://') else '0'}\n"
              f"PG_GYM_UID={uid}\nPG_GYM_GID={gid}\n")
    (directory / "platform.env").write_text(config)
    result = {"directory": str(directory), "next": f"Run pg-gym platform start --directory {directory}"}
    if not open_registration:
        result["registration_code"] = f"pg-gym platform registration-code --directory {directory}"
    return result


def build_platform_images(source: Path, gpu: bool = False) -> dict:
    source = source.expanduser().resolve()
    if not (source / "web" / "deno.json").is_file():
        raise ValueError("--source must point to the complete release repository")
    checked(["docker", "build", "-f", "deploy/platform/Dockerfile.api", "-t", "pg-gym-api:" + __version__, "."], cwd=source)
    checked(["docker", "build", "-f", "deploy/platform/Dockerfile.web", "-t", "pg-gym-web:" + __version__, "."], cwd=source)
    if gpu:
        checked(["docker", "build", "--build-arg", "TRAINING=1", "-f", "deploy/platform/Dockerfile.api", "-t", "pg-gym-gpu:" + __version__, "."], cwd=source)
        checked(["docker", "pull", os.environ.get("PG_GYM_VLLM_IMAGE", "vllm/vllm-openai:v0.27.0")])
    return {"images": ["pg-gym-api:" + __version__, "pg-gym-web:" + __version__]}


def compose_platform(directory: Path, action: str, *, gpu: bool = False,
                     service: str | None = None, follow: bool = False,
                     timeout: float = 60.0) -> dict:
    directory = directory.expanduser().resolve()
    command = ["docker", "compose", "--project-name", "pg-gym", "--env-file",
               str(directory / "platform.env"), "-f", str(directory / "compose.yaml")]
    if action == "up":
        if gpu:
            command += ["--profile", "gpu"]
        command += ["up", "-d", "--wait", "--wait-timeout", str(int(timeout))]
    elif action == "down":
        command += ["--profile", "gpu", "down"]
    elif action == "status":
        command += ["ps", "--format", "json"]
    elif action == "logs":
        command += ["logs", "--tail", "200"]
        if follow:
            command.append("--follow")
        if service:
            command.append(service)
    else:
        raise ValueError("Unknown compose action")
    checked(command, cwd=directory)
    return {"ok": True}


def start_platform(source: Path, directory: Path, origin: str = "http://localhost:8000",
                   gpu: bool = False, open_registration: bool = False,
                   timeout: float = 60.0) -> dict:
    source = source.expanduser().resolve()
    directory = directory.expanduser().resolve()
    if not (source / "web" / "deno.json").is_file():
        raise ValueError("--source must point to the complete release repository")
    if not (directory / "compose.yaml").exists():
        initialize_instance(directory, origin, open_registration)
    elif not (directory / "platform.env").is_file():
        raise ValueError("Instance is incomplete: platform.env is missing")
    values = dict(line.split("=", 1) for line in (directory / "platform.env").read_text().splitlines()
                  if "=" in line and not line.startswith("#"))
    if open_registration and values.get("PG_GYM_OPEN_REGISTRATION") != "1":
        raise ValueError("For an existing instance, configure PG_GYM_OPEN_REGISTRATION in platform.env and its Compose API environment.")
    build_platform_images(source, gpu)
    compose_platform(directory, "up", gpu=gpu, timeout=timeout)
    result = {"ok": True, "directory": str(directory), "url": values.get("PG_GYM_ORIGIN", origin)}
    if values.get("PG_GYM_OPEN_REGISTRATION") != "1":
        result["registration_code"] = f"pg-gym platform registration-code --directory {directory}"
    return result


def operate(args):
    if args.group == "server":
        if args.action == "api":
            import uvicorn
            uvicorn.run("postgres_gym_platform.api:create_app", factory=True, host=args.host, port=args.port, workers=1, log_level="info", proxy_headers=False)
        else:
            from .config import Config
            from .worker import run_worker
            cfg = Config.from_env()
            run_worker(args.url, cfg.worker_token, args.directory.resolve(), args.id)
        return None
    if args.group == "doctor":
        from .config import project_root
        return {"version": __version__, "python": sys.version.split()[0], "root": str(project_root()),
                "docker": shutil.which("docker"), "nvidia_smi": shutil.which("nvidia-smi"), "suites_present": (project_root() / "suites").is_dir()}
    if args.group == "storage":
        return storage(args)
    if args.group == "dev":
        return development(args)
    directory = args.directory.expanduser().resolve()
    if args.action == "start":
        return start_platform(args.source, directory, args.origin, args.gpu,
                              args.open_registration, args.timeout)
    if args.action == "init":
        return initialize_instance(directory, args.origin, args.open_registration)
    if args.action == "build":
        return build_platform_images(args.source, args.gpu)
    if args.action == "registration-code":
        return {"registration_code": (directory / "secrets" / "registration-token").read_text().strip()}
    return compose_platform(directory, args.action, gpu=args.gpu, service=args.service,
                            follow=args.follow, timeout=args.timeout)


def download_artifact(client, identifier: str, directory: Path) -> dict:
    artifact = client.request("GET", "/artifacts/" + identifier)
    if artifact["status"] != "ready":
        raise ValueError("Artifact is not complete")
    directory = directory.expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    for item in artifact["files"]:
        relative = Path(item["path"])
        if relative.is_absolute() or ".." in relative.parts or "\\" in item["path"]:
            raise ValueError("Invalid artifact path")
        path = directory / relative
        if not path.resolve().is_relative_to(directory):
            raise ValueError("Artifact path escapes the destination")
        if path.exists():
            with path.open("rb") as source:
                if hashlib.file_digest(source, "sha256").hexdigest() == item["sha256"]:
                    continue
            raise ValueError("Refusing to overwrite a different file: " + str(path))
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(dir=path.parent, prefix=".download-")
        os.close(descriptor)
        temporary = Path(name)
        with client.http.stream("GET", "/api/v1/artifacts/" + identifier + "/files/" + quote(item["path"], safe="/")) as response:
            response.raise_for_status()
            checksum = hashlib.sha256()
            with temporary.open("wb") as output:
                for chunk in response.iter_bytes(1024**2):
                    output.write(chunk)
                    checksum.update(chunk)
        if checksum.hexdigest() != item["sha256"] or temporary.stat().st_size != item["size"]:
            temporary.unlink()
            raise ValueError("Artifact checksum mismatch")
        temporary.replace(path)
    (directory / "pg-gym-manifest.json").write_text(json.dumps(artifact, indent=2))
    return {"artifact_id": identifier, "directory": str(directory), "files": len(artifact["files"])}


def local_benchmark(args) -> dict:
    if args.config or args.min_solve_rate is not None:
        raise ValueError("Local mode uses direct library settings; --config and --min-solve-rate require REST")
    if not args.suite:
        raise ValueError("--suite is required")
    if args.connection or args.profile:
        raise ValueError("Local mode uses the library environment; platform connection/profile IDs require REST")
    from postgres_gym import Gym
    gym = Gym(args.suite)
    episodes = []
    available = gym.tasks(args.split)
    if any(name not in available for name in args.task or []):
        raise ValueError("Select tasks within the requested split")
    for name in args.task or available:
        result = gym.run(name, "cli:" + args.harness)
        episodes.append({"task": name, "reward": result.reward, "record": result.record, "execution_ok": result.ok, "error": result.execution.stderr if not result.ok else None})
    return {"episodes": episodes, "execution_errors": sum(not e["execution_ok"] for e in episodes)}


def development(args):
    source = args.source.resolve()
    os.environ["POSTGRES_GYM_ROOT"] = str(source)
    if args.action == "stand-fetch":
        path = source / "stand" / "pg.git"
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            checked(["git", "clone", "--bare", os.environ.get("POSTGRES_GYM_PG_MIRROR", "https://git.postgresql.org/git/postgresql.git"), str(path)])
        checked(["git", "--git-dir=" + str(path), "update-ref", "refs/postgres-gym/pristine", "aa14281fdde6b2cc7a794dd02bc128dd0cb20b45"])
    elif args.action == "image":
        command = ["docker", "build", "-f", "deploy/task/Dockerfile", "-t", os.environ.get("POSTGRES_GYM_TASK_IMAGE", "postgres-gym-task:17.11")]
        if value := os.environ.get("MARKOV_SHA256"):
            command += ["--build-arg", "MARKOV_SHA256=" + value]
        checked([*command, "."], cwd=source)
    else:
        from postgres_gym import Gym
        from postgres_gym.core import data, registry
        if args.action == "suite-check":
            issues = data.validate(registry.load(args.suite))
            if issues:
                raise ValueError("\n".join(issues))
        elif args.action == "verify":
            return Gym(args.suite).verify(args.task)
        else:
            return {agent: Gym(args.suite).run(args.task, agent).record for agent in ("replay", "noop", "cheat", "probe")}
    return {"ok": True}


def storage(args):
    from .config import Config
    from .db import Database
    cfg = Config.from_env()
    if args.action == "reset-password":
        from .cli import prompt_value
        from .security import PASSWORDS
        password = sys.stdin.readline().rstrip("\n") if args.password_stdin else prompt_value("New password", secret=True)
        if not 12 <= len(password) <= 256:
            raise ValueError("Password must contain 12 to 256 characters")
        with Database(cfg.data / "platform.sqlite").connect(write=True) as db:
            row = db.execute("SELECT id FROM users WHERE username=?", (args.username,)).fetchone()
            if not row:
                raise ValueError("User not found")
            db.execute("UPDATE users SET password_hash=? WHERE id=?", (PASSWORDS.hash(password), row["id"]))
            db.execute("DELETE FROM sessions WHERE user_id=?", (row["id"],))
        return {"ok": True}
    if args.action == "backup":
        if not (cfg.data / "platform.sqlite").exists():
            raise ValueError("Database not found")
        if args.path.exists():
            raise ValueError("Backup destination already exists")
        with tempfile.TemporaryDirectory() as temporary:
            snapshot = Path(temporary) / "platform.sqlite"
            Database(cfg.data / "platform.sqlite").backup(snapshot)
            with zipfile.ZipFile(args.path, "x", compression=zipfile.ZIP_STORED) as archive:
                args.path.chmod(0o600)
                archive.write(snapshot, "platform.sqlite")
                for name in ("master.key", "worker-token", "registration-token"):
                    if (cfg.secret_dir / name).is_file():
                        archive.write(cfg.secret_dir / name, "secrets/" + name)
                for file in (cfg.data / "artifacts").rglob("*"):
                    if file.is_file() and not file.is_symlink() and ".upload-" not in file.name:
                        archive.write(file, file.relative_to(cfg.data))
        return {"path": str(args.path.resolve()), "at": time.time()}
    if any(p.exists() and any(p.iterdir()) for p in (cfg.data, cfg.secret_dir)):
        raise ValueError("Restore requires an empty instance with API and workers stopped")
    cfg.data.mkdir(parents=True, exist_ok=True, mode=0o700)
    cfg.secret_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    with zipfile.ZipFile(args.path) as archive:
        if not {"platform.sqlite", "secrets/master.key"}.issubset(archive.namelist()):
            raise ValueError("Backup is missing the database or master key")
        names = archive.namelist()
        if len(set(names)) != len(names):
            raise ValueError("Duplicate backup members")
        for item in archive.infolist():
            relative = Path(item.filename)
            if relative.is_absolute() or ".." in relative.parts or "\\" in item.filename or item.is_dir() or (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Invalid backup member")
            if item.filename not in {"platform.sqlite", "secrets/master.key", "secrets/worker-token", "secrets/registration-token"} and relative.parts[0] != "artifacts":
                raise ValueError("Unexpected backup member")
        for item in archive.infolist():
            relative = Path(item.filename)
            target = cfg.secret_dir / relative.name if relative.parts[0] == "secrets" else cfg.data / relative
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            with archive.open(item) as source, target.open("xb") as output:
                target.chmod(0o600)
                shutil.copyfileobj(source, output)
    return {"ok": True, "data": str(cfg.data)}
