from __future__ import annotations

import argparse
import getpass
import json
import math
import os
import sys
import time
import uuid
from pathlib import Path

import httpx

from . import __version__
from .client import ApiError, Client, read_contexts, write_contexts


def common(parser):
    for name, kwargs in (("--context", {}), ("--output", {"choices": ["table", "json", "jsonl"]}), ("--timeout", {"type": float}), ("--no-color", {"action": "store_true"})):
        parser.add_argument(name, default=argparse.SUPPRESS, **kwargs)


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="pg-gym", description="Postgres Gym platform and experiment CLI")
    common(root)
    root.set_defaults(context=None, output="table", timeout=60.0, no_color=False)
    root.add_argument("--version", action="version", version="pg-gym " + __version__)
    groups = root.add_subparsers(dest="group", required=True)
    def group(name, actions):
        parent = groups.add_parser(name)
        common(parent)
        subs = parent.add_subparsers(dest="action", required=True)
        result = {}
        for action in actions:
            result[action] = subs.add_parser(action)
            common(result[action])
        return result
    context = group("context", ["add", "list", "use"])
    for action in ("add", "use"):
        context[action].add_argument("name")
    context["add"].add_argument("--url", required=True)
    auth = group("auth", ["login", "register", "logout", "status"])
    for action in ("login", "register"):
        auth[action].add_argument("--username")
        auth[action].add_argument("--password-stdin", action="store_true")
    auth["login"].add_argument("--token-stdin", action="store_true")
    auth["register"].add_argument("--invitation-stdin", action="store_true")
    jobs = group("jobs", ["list", "show", "wait", "logs", "cancel", "retry"])
    jobs["list"].add_argument("--kind")
    for action in ("show", "wait", "logs", "cancel", "retry"):
        jobs[action].add_argument("id")
    jobs["logs"].add_argument("--follow", action="store_true")
    benchmark = group("benchmark", ["run"])["run"]
    benchmark.add_argument("--suite")
    benchmark.add_argument("--task", action="append")
    benchmark.add_argument("--split")
    benchmark.add_argument("--harness", choices=["markov", "opencode"], default="markov")
    benchmark.add_argument("--connection")
    benchmark.add_argument("--profile")
    benchmark.add_argument("--local", action="store_true")
    benchmark.add_argument("--min-solve-rate", type=float)
    rl = group("rl", ["train", "evaluate"])
    for action in rl.values():
        action.add_argument("--artifact")
        action.add_argument("--suite")
        action.add_argument("--split")
    inference = group("inference", ["deploy", "list", "stop", "chat"])
    inference["chat"].add_argument("--connection", action="append")
    inference["chat"].add_argument("--conversation")
    inference["chat"].add_argument("--prompt")
    inference["chat"].add_argument("--prompt-stdin", action="store_true")
    inference["chat"].add_argument("--max-tokens", type=int, default=2048)
    inference["chat"].add_argument("--temperature", type=float, default=0.7)
    inference["deploy"].add_argument("--artifact")
    inference["stop"].add_argument("id")
    models = group("models", ["pull", "list"])
    models["pull"].add_argument("repository", nargs="?")
    models["pull"].add_argument("--revision", default="main")
    models["pull"].add_argument("--credential")
    for action in [benchmark, *rl.values(), inference["deploy"], models["pull"]]:
        action.add_argument("--config", type=Path)
        action.add_argument("--name")
        action.add_argument("--wait", action="store_true")
        action.add_argument("--idempotency-key")
    group("suites", ["list"])
    tasks = group("tasks", ["list"])["list"]
    tasks.add_argument("--suite", required=True)
    tasks.add_argument("--split")
    for resource in ("connections", "harnesses", "credentials"):
        actions = group(resource, ["list", "create", "delete"] + (["check"] if resource == "connections" else []))
        actions["create"].add_argument("--config", type=Path, required=True)
        actions["delete"].add_argument("id")
        if resource == "connections":
            actions["check"].add_argument("id")
    artifacts = group("artifacts", ["list", "show", "download"])
    for action in ("show", "download"):
        artifacts[action].add_argument("id")
    artifacts["download"].add_argument("--directory", type=Path, required=True)
    platform = group("platform", ["start", "init", "build", "up", "down", "status", "logs", "registration-code"])
    for action in platform.values():
        action.add_argument("--directory", type=Path, default=Path("pg-gym-instance"))
    platform["start"].add_argument("--open-registration", action="store_true", help="Allow account creation without a code in a new instance")
    platform["init"].add_argument("--open-registration", action="store_true")
    platform["start"].add_argument("--origin", default="http://localhost:8000")
    platform["start"].add_argument("--source", type=Path, default=Path.cwd())
    platform["start"].add_argument("--gpu", action="store_true")
    platform["init"].add_argument("--origin", default="http://localhost:8000")
    platform["build"].add_argument("--source", type=Path, default=Path.cwd())
    platform["up"].add_argument("--gpu", action="store_true")
    platform["build"].add_argument("--gpu", action="store_true")
    platform["logs"].add_argument("--service", choices=["web", "api", "worker", "worker-gpu"])
    platform["logs"].add_argument("--follow", action="store_true")
    server = group("server", ["api", "worker"])
    server["api"].add_argument("--host", default="127.0.0.1")
    server["api"].add_argument("--port", type=int, default=8001)
    server["worker"].add_argument("--url", default=os.environ.get("PG_GYM_API_URL", "http://127.0.0.1:8001"))
    server["worker"].add_argument("--directory", type=Path, default=Path(os.environ.get("PG_GYM_WORKER_DATA", "~/.local/share/pg-gym/worker")).expanduser())
    server["worker"].add_argument("--id", default=os.environ.get("PG_GYM_WORKER_ID", "local"))
    doctor = groups.add_parser("doctor")
    common(doctor)
    doctor.add_argument("--local", action="store_true")
    dev = group("dev", ["stand-fetch", "image", "suite-check", "verify", "selftest"])
    for action in dev.values():
        action.add_argument("--source", type=Path, default=Path.cwd())
        action.add_argument("--suite", default="sql-function-set")
        action.add_argument("--task", default="area")
    storage = group("storage", ["backup", "restore", "reset-password"])
    for action in ("backup", "restore"):
        storage[action].add_argument("path", type=Path)
    storage["reset-password"].add_argument("username")
    storage["reset-password"].add_argument("--password-stdin", action="store_true")
    return root


def display(value, args):
    if args.output in {"json", "jsonl"}:
        print(json.dumps(value, ensure_ascii=False, allow_nan=False))
    else:
        from rich.console import Console
        Console(no_color=args.no_color, force_terminal=False if not sys.stdout.isatty() else None).print_json(json.dumps(value, ensure_ascii=False))


def get_client(args) -> tuple[Client, dict, str | None]:
    contexts = read_contexts()
    name = args.context or contexts["active"]
    configured = contexts["contexts"].get(name, {})
    url = os.environ.get("PG_GYM_URL") or configured.get("url")
    if not url:
        raise ValueError("Configure a context with pg-gym context add NAME --url URL, or set PG_GYM_URL")
    token = os.environ.get("PG_GYM_TOKEN") or configured.get("token", "")
    return Client(url, token, args.timeout), contexts, name


def prompt_value(label: str, *, secret: bool = False) -> str:
    if not sys.stdin.isatty():
        raise ValueError(f"{label} is required in non-interactive mode")
    return getpass.getpass(label + ": ") if secret else input(label + ": ")


def wait_job(client: Client, identifier: str, timeout: float) -> dict:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        job = client.request("GET", "/jobs/" + identifier)
        if job["status"] in {"succeeded", "failed", "cancelled"}:
            return job
        time.sleep(min(2, max(0, deadline - time.monotonic())))
    raise TimeoutError("Waiting timed out; the remote job continues. Job: " + identifier)


def run(args) -> int:
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        raise ValueError("--timeout must be finite and positive")
    threshold = getattr(args, "min_solve_rate", None)
    if threshold is not None and (not args.wait or not 0 <= threshold <= 1):
        raise ValueError("--min-solve-rate requires --wait and a value between 0 and 1")
    if args.group == "context":
        contexts = read_contexts()
        if args.action == "add":
            from urllib.parse import urlsplit
            parsed = urlsplit(args.url)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise ValueError("Use an HTTP(S) API URL without credentials")
            contexts["contexts"][args.name] = {"url": args.url.rstrip("/")}
            contexts["active"] = contexts["active"] or args.name
        elif args.action == "use":
            if args.name not in contexts["contexts"]:
                raise ValueError("Unknown context")
            contexts["active"] = args.name
        if args.action != "list":
            write_contexts(contexts)
        display({"active": contexts["active"], "contexts": {name: {"url": cfg["url"], "authenticated": bool(cfg.get("token"))} for name, cfg in contexts["contexts"].items()}}, args)
        return 0
    if args.group in {"platform", "server", "dev", "storage"} or args.group == "doctor" and args.local:
        from .operations import operate
        value = operate(args)
        if value is not None:
            display(value, args)
        return 0
    if args.group == "benchmark" and args.local:
        if args.context:
            raise ValueError("--local and --context cannot be used together")
        from .operations import local_benchmark
        result = local_benchmark(args)
        display(result, args)
        return 1 if result["execution_errors"] else 0
    client, contexts, context = get_client(args)
    try:
        if args.group == "auth":
            if args.action == "status":
                display(client.request("GET", "/me"), args)
            elif args.action == "logout":
                client.request("POST", "/auth/logout")
                if context:
                    contexts["contexts"][context].pop("token", None)
                    write_contexts(contexts)
                display({"ok": True}, args)
            else:
                if getattr(args, "token_stdin", False):
                    token = sys.stdin.read().strip()
                    client.http.headers["Authorization"] = "Bearer " + token
                    user = client.request("GET", "/me")
                else:
                    username = args.username or prompt_value("Username")
                    password = sys.stdin.readline().rstrip("\n") if args.password_stdin else prompt_value("Password", secret=True)
                    body = {"username": username, "password": password}
                    if args.action == "register":
                        body["invitation"] = sys.stdin.readline().strip() if args.invitation_stdin else os.environ.get("PG_GYM_REGISTRATION_TOKEN") or prompt_value("Registration code", secret=True)
                        display(client.request("POST", "/auth/register", json=body), args)
                        return 0
                    issued = client.request("POST", "/auth/token", json=body)
                    token, user = issued["token"], issued["user"]
                if not context:
                    raise ValueError("Create a named context before saving a login")
                contexts["contexts"][context]["token"] = token
                write_contexts(contexts)
                display(user, args)
            return 0
        if args.group in {"benchmark", "rl", "models", "inference"} and args.action in {"run", "train", "evaluate", "pull", "deploy"}:
            body = json.loads(args.config.read_text()) if args.config else {}
            if args.name:
                body["name"] = args.name
            if not args.config:
                if args.group == "benchmark":
                    body.update(suite=args.suite, tasks=args.task or [], split=args.split, harness=args.harness, connection_id=args.connection, profile_id=args.profile)
                elif args.group == "rl":
                    body.update(artifact_id=args.artifact, suite=args.suite, split=args.split or ("train" if args.action == "train" else "test"))
                elif args.group == "models":
                    body.update(repository=args.repository, revision=args.revision, credential_id=args.credential)
                else:
                    body.update(artifact_id=args.artifact)
            path = {"benchmark": "/benchmarks", "models": "/models/imports", "inference": "/deployments", "rl": "/training-runs" if args.action == "train" else "/evaluations"}[args.group]
            key = args.idempotency_key or uuid.uuid4().hex
            try:
                job = client.request("POST", path, json=body, headers={"Idempotency-Key": key})
            except httpx.HTTPError:
                print("Submission was not confirmed. Reuse --idempotency-key " + key + " to reconcile this request.", file=sys.stderr)
                raise
            if args.wait:
                print("Job: " + job["id"], file=sys.stderr)
                job = wait_job(client, job["id"], args.timeout)
            display(job, args)
            if args.wait and job["status"] != "succeeded":
                return 1
            threshold = getattr(args, "min_solve_rate", None)
            if threshold is not None:
                if not args.wait or not 0 <= threshold <= 1:
                    raise ValueError("--min-solve-rate requires --wait and a value between 0 and 1")
                if (job.get("result") or {}).get("solve_rate", 0) < threshold:
                    return 6
            return 0
        if args.group == "inference" and args.action == "chat":
            prompt = sys.stdin.read() if args.prompt_stdin else args.prompt or prompt_value("Message")
            conversation = args.conversation
            if not conversation:
                if not args.connection:
                    raise ValueError("--connection or --conversation is required")
                conversation = client.request("POST", "/conversations", json={"connection_ids": args.connection, "temperature": args.temperature, "max_tokens": args.max_tokens})["id"]
            job = client.request("POST", "/conversations/" + conversation + "/turns", json={"prompt": prompt}, headers={"Idempotency-Key": uuid.uuid4().hex})
            print("Conversation: " + conversation + "; job: " + job["id"], file=sys.stderr)
            result = wait_job(client, job["id"], args.timeout)
            display({"conversation_id": conversation, "job": result}, args)
            return 0 if result["status"] == "succeeded" else 1
        if args.group == "jobs":
            if args.action == "list":
                result = client.request("GET", "/jobs", params={"kind": args.kind} if args.kind else {})
            elif args.action == "wait":
                result = wait_job(client, args.id, args.timeout)
            elif args.action == "logs":
                cursor = 0
                while True:
                    page = client.request("GET", "/jobs/" + args.id + "/events", params={"after": cursor})
                    for event in page["items"]:
                        display(event, args)
                    cursor = page["next"]
                    job = client.request("GET", "/jobs/" + args.id)
                    if not args.follow and not page["items"] or job["status"] in {"succeeded", "failed", "cancelled"} and not page["items"]:
                        return 0
                    if not page["items"]:
                        time.sleep(1)
            else:
                suffix = {"show": "", "cancel": "/cancel", "retry": "/retries"}[args.action]
                result = client.request("GET" if args.action == "show" else "POST", "/jobs/" + args.id + suffix, headers={"Idempotency-Key": uuid.uuid4().hex})
            display(result, args)
            return 1 if args.action == "wait" and result["status"] != "succeeded" else 0
        if args.group == "artifacts" and args.action == "download":
            from .operations import download_artifact
            display(download_artifact(client, args.id, args.directory), args)
            return 0
        if args.group in {"connections", "credentials", "harnesses"}:
            path = {"connections": "/connections", "credentials": "/secrets", "harnesses": "/harness-profiles"}[args.group]
            if args.action == "create":
                result = client.request("POST", path, json=json.loads(args.config.read_text()))
            elif args.action == "list":
                result = client.request("GET", path)
            else:
                result = client.request("DELETE" if args.action == "delete" else "POST", path + "/" + args.id + ("/check" if args.action == "check" else ""))
        elif args.group == "inference":
            result = client.request("POST", "/deployments/" + args.id + "/stop") if args.action == "stop" else client.request("GET", "/jobs", params={"kind": "deployment"})
        elif args.group == "tasks":
            result = client.request("GET", "/suites/" + args.suite + "/tasks", params={"split": args.split} if args.split else {})
        else:
            path = {"doctor": "/capabilities", "suites": "/suites", "models": "/artifacts", "artifacts": "/artifacts"}[args.group]
            if args.group == "artifacts" and args.action == "show":
                path += "/" + args.id
            result = client.request("GET", path)
        display(result, args)
        return 0
    finally:
        client.close()


def main(argv: list[str] | None = None):
    args = parser().parse_args(argv)
    try:
        raise SystemExit(run(args))
    except ApiError as exc:
        print(json.dumps({"error": {"code": exc.code, "message": str(exc)}}), file=sys.stderr)
        raise SystemExit(3 if exc.status in {401, 403} else 2 if exc.status in {400, 422} else 1) from None
    except httpx.HTTPError as exc:
        print(json.dumps({"error": {"code": "network_error", "message": type(exc).__name__}}), file=sys.stderr)
        raise SystemExit(4) from None
    except TimeoutError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(124) from None
    except (ValueError, OSError, KeyError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(2) from None
    except KeyboardInterrupt:
        print("Client interrupted. Remote jobs continue; use pg-gym jobs cancel to stop one.", file=sys.stderr)
        raise SystemExit(130) from None


if __name__ == "__main__":
    main()
