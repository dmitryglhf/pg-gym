from __future__ import annotations

import json
import math
import os
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated
from urllib.parse import urlsplit

import httpx
import typer

from postgres_gym.cli_core import CliContext, OutputMode, emit

from . import __version__, operations
from .client import ApiError, Client, read_contexts, write_contexts


@dataclass
class _State:
    output: OutputMode = OutputMode.table
    no_color: bool = False
    context: str | None = None
    timeout: float = 60.0


_STATE = _State()
_DEFAULT_SOURCE = Path.cwd()
_DEFAULT_WORKER_DIR = Path(os.environ.get("PG_GYM_WORKER_DATA", "~/.local/share/pg-gym/worker")).expanduser()
_DEFAULT_WORKER_URL = os.environ.get("PG_GYM_API_URL", "http://127.0.0.1:8001")
_DEFAULT_WORKER_ID = os.environ.get("PG_GYM_WORKER_ID", "local")
app = typer.Typer(name="pg-gym", help="Postgres Gym platform, benchmark and inference CLI.", no_args_is_help=True, add_completion=False)
platform_app = typer.Typer(help="Create and operate a local platform instance.")
benchmark_app = typer.Typer(help="Run agent benchmarks.")
jobs_app = typer.Typer(help="Inspect and control jobs.")
inference_app = typer.Typer(help="Chat and manage inference servers.")
auth_app = typer.Typer(help="Authenticate against a platform.")
context_app = typer.Typer(help="Manage platform contexts.")
suites_app = typer.Typer(help="Inspect installed suites.")
tasks_app = typer.Typer(help="Inspect runnable tasks.")
models_app = typer.Typer(help="Import and list model artifacts.")
rl_app = typer.Typer(help="Train and evaluate models.")
resources_app = typer.Typer(help="Manage connections, credentials and profiles.")
artifacts_app = typer.Typer(help="Inspect and download artifacts.")
dev_app = typer.Typer(help="Development and verification commands.")
server_app = typer.Typer(help="Run the API or a worker process.")
storage_app = typer.Typer(help="Back up and restore platform data.")
for group, name in ((platform_app, "platform"), (benchmark_app, "benchmark"), (jobs_app, "jobs"),
                    (inference_app, "inference"), (auth_app, "auth"), (context_app, "context"),
                    (suites_app, "suites"), (tasks_app, "tasks"), (models_app, "models"),
                    (rl_app, "rl"), (resources_app, "resources"), (artifacts_app, "artifacts"),
                    (dev_app, "dev"), (server_app, "server"), (storage_app, "storage")):
    app.add_typer(group, name=name)


def _show(value) -> None:
    emit(value, CliContext(_STATE.output, _STATE.no_color))


def _remote() -> tuple[Client, dict, str | None]:
    contexts = read_contexts()
    name = _STATE.context or contexts.get("active")
    configured = contexts.get("contexts", {}).get(name, {}) if name else {}
    url = os.environ.get("PG_GYM_URL") or configured.get("url")
    if not url:
        raise ValueError("Configure a context with pg-gym context add NAME --url URL, or set PG_GYM_URL")
    token = os.environ.get("PG_GYM_TOKEN") or configured.get("token", "")
    return Client(url, token, _STATE.timeout), contexts, name


def _wait(client: Client, identifier: str) -> dict:
    deadline = time.monotonic() + _STATE.timeout
    while time.monotonic() < deadline:
        job = client.request("GET", "/jobs/" + identifier)
        if job.get("status") in {"succeeded", "failed", "cancelled"}:
            return job
        time.sleep(min(2, max(0, deadline - time.monotonic())))
    raise TimeoutError("Waiting timed out; the remote job continues. Job: " + identifier)


def _submit(client: Client, path: str, body: dict, wait: bool, key: str | None = None) -> dict:
    idempotency_key = key or uuid.uuid4().hex
    try:
        job = client.request("POST", path, json=body, headers={"Idempotency-Key": idempotency_key})
    except httpx.HTTPError:
        print("Submission was not confirmed. Reuse --idempotency-key " + idempotency_key + " to reconcile this request.", file=sys.stderr)
        raise
    if wait:
        print("Job: " + job["id"], file=sys.stderr)
        job = _wait(client, job["id"])
    return job


@app.callback()
def root(version: Annotated[bool, typer.Option("--version", is_eager=True)] = False,
         context: Annotated[str | None, typer.Option("--context")] = None,
         output: Annotated[OutputMode, typer.Option("--output")] = OutputMode.table,
         json_output: Annotated[bool, typer.Option("--json", help="Shorthand for --output json.")] = False,
         jsonl_output: Annotated[bool, typer.Option("--jsonl", help="Shorthand for --output jsonl.")] = False,
         timeout: Annotated[float, typer.Option("--timeout")] = 60.0,
         no_color: Annotated[bool, typer.Option("--no-color")] = False) -> None:
    if version:
        typer.echo(f"pg-gym {__version__}")
        raise typer.Exit()
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("--timeout must be finite and positive")
    if json_output and jsonl_output:
        raise ValueError("--json and --jsonl cannot be used together")
    if json_output:
        output = OutputMode.json
    elif jsonl_output:
        output = OutputMode.jsonl
    _STATE.context, _STATE.output, _STATE.no_color, _STATE.timeout = context, output, no_color, timeout


@platform_app.command("start")
def platform_start(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE, directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance"), origin: Annotated[str, typer.Option("--origin")] = "http://localhost:8000", gpu: Annotated[bool, typer.Option("--gpu")] = False, open_registration: Annotated[bool, typer.Option("--open-registration")] = False) -> None:
    _show(operations.start_platform(source, directory, origin, gpu, open_registration, _STATE.timeout))


@platform_app.command("init")
def platform_init(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance"), origin: Annotated[str, typer.Option("--origin")] = "http://localhost:8000", open_registration: Annotated[bool, typer.Option("--open-registration")] = False) -> None:
    _show(operations.initialize_instance(directory, origin, open_registration))


@platform_app.command("build")
def platform_build(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE, gpu: Annotated[bool, typer.Option("--gpu")] = False) -> None:
    _show(operations.build_platform_images(source, gpu))


@platform_app.command("up")
def platform_up(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance"), gpu: Annotated[bool, typer.Option("--gpu")] = False) -> None:
    _show(operations.compose_platform(directory, "up", gpu=gpu, timeout=_STATE.timeout))


@platform_app.command("down")
def platform_down(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance")) -> None:
    _show(operations.compose_platform(directory, "down", timeout=_STATE.timeout))


@platform_app.command("status")
def platform_status(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance")) -> None:
    _show(operations.compose_platform(directory, "status", timeout=_STATE.timeout))


@platform_app.command("logs")
def platform_logs(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance"), service: Annotated[str | None, typer.Option("--service")] = None, follow: Annotated[bool, typer.Option("--follow")] = False) -> None:
    _show(operations.compose_platform(directory, "logs", service=service, follow=follow, timeout=_STATE.timeout))


@platform_app.command("registration-code")
def platform_registration_code(directory: Annotated[Path, typer.Option("--directory")] = Path("pg-gym-instance")) -> None:
    _show({"registration_code": (directory.expanduser().resolve() / "secrets" / "registration-token").read_text().strip()})


@server_app.command("api")
def server_api(host: Annotated[str, typer.Option("--host")] = "127.0.0.1", port: Annotated[int, typer.Option("--port")] = 8001) -> None:
    import uvicorn
    uvicorn.run("postgres_gym_platform.api:create_app", factory=True, host=host, port=port, workers=1, log_level="info", proxy_headers=False)


@server_app.command("worker")
def server_worker(url: Annotated[str, typer.Option("--url")] = _DEFAULT_WORKER_URL, directory: Annotated[Path, typer.Option("--directory")] = _DEFAULT_WORKER_DIR, identifier: Annotated[str, typer.Option("--id")] = _DEFAULT_WORKER_ID) -> None:
    from .config import Config
    from .worker import run_worker
    cfg = Config.from_env()
    run_worker(url, cfg.worker_token, directory.resolve(), identifier)


@app.command("doctor")
def doctor() -> None:
    import shutil

    from .config import project_root
    _show({"version": __version__, "python": sys.version.split()[0], "root": str(project_root()), "docker": shutil.which("docker"), "nvidia_smi": shutil.which("nvidia-smi"), "suites_present": (project_root() / "suites").is_dir()})


@storage_app.command("backup")
def storage_backup(path: Path) -> None:
    from types import SimpleNamespace
    _show(operations.storage(SimpleNamespace(action="backup", path=path)))


@storage_app.command("restore")
def storage_restore(path: Path) -> None:
    from types import SimpleNamespace
    _show(operations.storage(SimpleNamespace(action="restore", path=path)))


@storage_app.command("reset-password")
def storage_reset_password(username: str, password_stdin: Annotated[bool, typer.Option("--password-stdin")] = False) -> None:
    from types import SimpleNamespace
    _show(operations.storage(SimpleNamespace(action="reset-password", username=username, password_stdin=password_stdin)))


@benchmark_app.command("run")
def benchmark_run(suite: Annotated[str | None, typer.Option("--suite")] = None, task: Annotated[list[str] | None, typer.Option("--task")] = None, split: Annotated[str | None, typer.Option("--split")] = None, harness: Annotated[str, typer.Option("--harness")] = "markov", connection: Annotated[str | None, typer.Option("--connection")] = None, profile: Annotated[str | None, typer.Option("--profile")] = None, local: Annotated[bool, typer.Option("--local")] = False, wait: Annotated[bool, typer.Option("--wait")] = False, min_solve_rate: Annotated[float | None, typer.Option("--min-solve-rate")] = None, config: Annotated[Path | None, typer.Option("--config")] = None, name: Annotated[str | None, typer.Option("--name")] = None, idempotency_key: Annotated[str | None, typer.Option("--idempotency-key")] = None) -> None:
    if local:
        if _STATE.context or config or connection or profile or min_solve_rate is not None:
            raise ValueError("Local mode uses direct library settings and cannot use REST options")
        if not suite:
            raise ValueError("--suite is required")
        from postgres_gym import Gym
        gym = Gym(suite)
        available = gym.tasks(split)
        selected = task or available
        if any(item not in available for item in selected):
            raise ValueError("Select tasks within the requested split")
        episodes = []
        for item in selected:
            result = gym.run(item, "cli:" + harness)
            episodes.append({"task": item, "reward": result.reward, "record": result.record, "execution_ok": result.ok, "error": result.execution.stderr if not result.ok else None})
        _show({"episodes": episodes, "execution_errors": sum(not e["execution_ok"] for e in episodes)})
        return
    client, _, _ = _remote()
    try:
        body = json.loads(config.read_text()) if config else {"suite": suite, "tasks": task or [], "split": split, "harness": harness, "connection_id": connection, "profile_id": profile}
        if name:
            body["name"] = name
        if min_solve_rate is not None and (not wait or not 0 <= min_solve_rate <= 1):
            raise ValueError("--min-solve-rate requires --wait and a value between 0 and 1")
        result = _submit(client, "/benchmarks", body, wait, idempotency_key)
        _show(result)
        if wait and result.get("status") != "succeeded":
            raise typer.Exit(1)
        if min_solve_rate is not None and (result.get("result") or {}).get("solve_rate", 0) < min_solve_rate:
            raise typer.Exit(6)
    finally:
        client.close()


@jobs_app.command("list")
def jobs_list(kind: Annotated[str | None, typer.Option("--kind")] = None) -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/jobs", params={"kind": kind} if kind else {}))
    finally:
        client.close()


def _job_action(identifier: str, action: str) -> None:
    client, _, _ = _remote()
    try:
        if action == "show":
            result = client.request("GET", "/jobs/" + identifier)
        elif action == "wait":
            result = _wait(client, identifier)
        elif action == "logs":
            cursor = 0
            while True:
                page = client.request("GET", f"/jobs/{identifier}/events", params={"after": cursor})
                for event in page["items"]:
                    _show(event)
                cursor = page["next"]
                job = client.request("GET", "/jobs/" + identifier)
                if not page["items"] and job["status"] in {"succeeded", "failed", "cancelled"}:
                    return
                if not page["items"]:
                    time.sleep(1)
        else:
            suffix = {"cancel": "/cancel", "retry": "/retries"}[action]
            result = client.request("POST", "/jobs/" + identifier + suffix, headers={"Idempotency-Key": uuid.uuid4().hex})
        _show(result)
        if action == "wait" and result.get("status") != "succeeded":
            raise typer.Exit(1)
    finally:
        client.close()


def _register_job_commands() -> None:
    for command_name in ("show", "wait", "logs", "cancel", "retry"):
        def command(identifier: str, _action: str = command_name) -> None:
            _job_action(identifier, _action)
        jobs_app.command(command_name)(command)


_register_job_commands()


@auth_app.command("login")
def auth_login(username: Annotated[str | None, typer.Option("--username")] = None, password_stdin: Annotated[bool, typer.Option("--password-stdin")] = False, token_stdin: Annotated[bool, typer.Option("--token-stdin")] = False) -> None:
    client, contexts, context = _remote()
    try:
        if token_stdin:
            token = sys.stdin.read().strip()
            client.http.headers["Authorization"] = "Bearer " + token
            user = client.request("GET", "/me")
        else:
            username = username or typer.prompt("Username")
            password = sys.stdin.readline().rstrip("\n") if password_stdin else typer.prompt("Password", hide_input=True)
            issued = client.request("POST", "/auth/token", json={"username": username, "password": password})
            token, user = issued["token"], issued["user"]
        if not context:
            raise ValueError("Create a named context before saving a login")
        contexts["contexts"][context]["token"] = token
        write_contexts(contexts)
        _show(user)
    finally:
        client.close()


@auth_app.command("register")
def auth_register(username: Annotated[str | None, typer.Option("--username")] = None, password_stdin: Annotated[bool, typer.Option("--password-stdin")] = False, invitation_stdin: Annotated[bool, typer.Option("--invitation-stdin")] = False) -> None:
    client, _, _ = _remote()
    try:
        username = username or typer.prompt("Username")
        password = sys.stdin.readline().rstrip("\n") if password_stdin else typer.prompt("Password", hide_input=True)
        invitation = sys.stdin.readline().strip() if invitation_stdin else os.environ.get("PG_GYM_REGISTRATION_TOKEN") or typer.prompt("Registration code", hide_input=True)
        _show(client.request("POST", "/auth/register", json={"username": username, "password": password, "invitation": invitation}))
    finally:
        client.close()


@auth_app.command("logout")
def auth_logout() -> None:
    client, contexts, context = _remote()
    try:
        client.request("POST", "/auth/logout")
        if context:
            contexts["contexts"][context].pop("token", None)
            write_contexts(contexts)
        _show({"ok": True})
    finally:
        client.close()


@auth_app.command("status")
def auth_status() -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/me"))
    finally:
        client.close()


@context_app.command("add")
def context_add(name: str, url: Annotated[str, typer.Option("--url")]) -> None:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Use an HTTP(S) API URL without credentials")
    contexts = read_contexts()
    contexts["contexts"][name] = {"url": url.rstrip("/")}
    contexts["active"] = contexts["active"] or name
    write_contexts(contexts)
    _show({"active": contexts["active"], "contexts": {key: {"url": value["url"], "authenticated": bool(value.get("token"))} for key, value in contexts["contexts"].items()}})


@context_app.command("list")
def context_list() -> None:
    contexts = read_contexts()
    _show({"active": contexts["active"], "contexts": {key: {"url": value["url"], "authenticated": bool(value.get("token"))} for key, value in contexts["contexts"].items()}})


@context_app.command("use")
def context_use(name: str) -> None:
    contexts = read_contexts()
    if name not in contexts["contexts"]:
        raise ValueError("Unknown context")
    contexts["active"] = name
    write_contexts(contexts)
    _show({"active": name})


@suites_app.command("list")
def suites_list() -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/suites"))
    finally:
        client.close()


@tasks_app.command("list")
def tasks_list(suite: Annotated[str, typer.Option("--suite")], split: Annotated[str | None, typer.Option("--split")] = None) -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", f"/suites/{suite}/tasks", params={"split": split} if split else {}))
    finally:
        client.close()


@tasks_app.command("show")
def tasks_show(suite: Annotated[str, typer.Option("--suite")], task: str) -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", f"/suites/{suite}/tasks/{task}"))
    finally:
        client.close()


@models_app.command("pull")
def models_pull(repository: str | None = None, revision: Annotated[str, typer.Option("--revision")] = "main", credential: Annotated[str | None, typer.Option("--credential")] = None, wait: Annotated[bool, typer.Option("--wait")] = False, config: Annotated[Path | None, typer.Option("--config")] = None, name: Annotated[str | None, typer.Option("--name")] = None, idempotency_key: Annotated[str | None, typer.Option("--idempotency-key")] = None) -> None:
    client, _, _ = _remote()
    try:
        if not config and not repository:
            raise ValueError("repository or --config is required")
        body = json.loads(config.read_text()) if config else {"repository": repository, "revision": revision, "credential_id": credential}
        if name:
            body["name"] = name
        _show(_submit(client, "/models/imports", body, wait, idempotency_key))
    finally:
        client.close()


@models_app.command("list")
def models_list() -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/artifacts"))
    finally:
        client.close()


def _run_job(path: str, body: dict, wait: bool) -> None:
    client, _, _ = _remote()
    try:
        _show(_submit(client, path, body, wait))
    finally:
        client.close()


@rl_app.command("train")
def rl_train(config: Annotated[Path | None, typer.Option("--config")] = None, artifact: Annotated[str | None, typer.Option("--artifact")] = None, suite: Annotated[str | None, typer.Option("--suite")] = None, split: Annotated[str, typer.Option("--split")] = "train", wait: Annotated[bool, typer.Option("--wait")] = False) -> None:
    body = json.loads(config.read_text()) if config else {"artifact_id": artifact, "suite": suite, "split": split}
    if not config and not artifact and not suite:
        raise ValueError("--config or training options are required")
    _run_job("/training-runs", body, wait)


@rl_app.command("evaluate")
def rl_evaluate(config: Annotated[Path | None, typer.Option("--config")] = None, artifact: Annotated[str | None, typer.Option("--artifact")] = None, suite: Annotated[str | None, typer.Option("--suite")] = None, split: Annotated[str, typer.Option("--split")] = "test", wait: Annotated[bool, typer.Option("--wait")] = False) -> None:
    body = json.loads(config.read_text()) if config else {"artifact_id": artifact, "suite": suite, "split": split}
    if not config and not artifact and not suite:
        raise ValueError("--config or evaluation options are required")
    _run_job("/evaluations", body, wait)


def _resource(action: str, identifier: str | None, config: Path | None, path: str) -> None:
    client, _, _ = _remote()
    try:
        if action == "create":
            if not config:
                raise ValueError("--config is required for create")
            result = client.request("POST", path, json=json.loads(config.read_text()))
        elif action == "list":
            result = client.request("GET", path)
        else:
            if not identifier:
                raise ValueError("identifier is required")
            result = client.request("DELETE", f"{path}/{identifier}")
        _show(result)
    finally:
        client.close()


def _resource_command_factory(path: str):
    def command(action: str, identifier: str | None = None, config: Path | None = None) -> None:
        _resource(action, identifier, config, path)
    return command


for _name, _path in (("connections", "/connections"), ("credentials", "/secrets"), ("profiles", "/harness-profiles")):
    resources_app.command(_name)(_resource_command_factory(_path))


@artifacts_app.command("list")
def artifacts_list() -> None:
    models_list()


@artifacts_app.command("show")
def artifacts_show(identifier: str) -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/artifacts/" + identifier))
    finally:
        client.close()


@artifacts_app.command("download")
def artifacts_download(identifier: str, directory: Annotated[Path, typer.Option("--directory")]) -> None:
    client, _, _ = _remote()
    try:
        _show(operations.download_artifact(client, identifier, directory))
    finally:
        client.close()


@inference_app.command("list")
def inference_list() -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("GET", "/jobs", params={"kind": "deployment"}))
    finally:
        client.close()


@inference_app.command("deploy")
def inference_deploy(artifact: Annotated[str | None, typer.Option("--artifact")] = None, config: Annotated[Path | None, typer.Option("--config")] = None, wait: Annotated[bool, typer.Option("--wait")] = False, name: Annotated[str | None, typer.Option("--name")] = None, idempotency_key: Annotated[str | None, typer.Option("--idempotency-key")] = None) -> None:
    client, _, _ = _remote()
    try:
        body = json.loads(config.read_text()) if config else {"artifact_id": artifact}
        if name:
            body["name"] = name
        _show(_submit(client, "/deployments", body, wait, idempotency_key))
    finally:
        client.close()


@inference_app.command("stop")
def inference_stop(identifier: str) -> None:
    client, _, _ = _remote()
    try:
        _show(client.request("POST", "/deployments/" + identifier + "/stop"))
    finally:
        client.close()


@inference_app.command("chat")
def inference_chat(connection: Annotated[list[str] | None, typer.Option("--connection")] = None, conversation: Annotated[str | None, typer.Option("--conversation")] = None, prompt: Annotated[str | None, typer.Option("--prompt")] = None, prompt_stdin: Annotated[bool, typer.Option("--prompt-stdin")] = False, max_tokens: Annotated[int, typer.Option("--max-tokens")] = 2048, temperature: Annotated[float, typer.Option("--temperature")] = 0.7) -> None:
    client, _, _ = _remote()
    try:
        prompt_text = sys.stdin.read() if prompt_stdin else prompt or typer.prompt("Message")
        if not conversation:
            if not connection:
                raise ValueError("--connection or --conversation is required")
            conversation = client.request("POST", "/conversations", json={"connection_ids": connection, "temperature": temperature, "max_tokens": max_tokens})["id"]
        job = client.request("POST", f"/conversations/{conversation}/turns", json={"prompt": prompt_text}, headers={"Idempotency-Key": uuid.uuid4().hex})
        print(f"Conversation: {conversation}; job: {job['id']}", file=sys.stderr)
        result = _wait(client, job["id"])
        _show({"conversation_id": conversation, "job": result})
        if result.get("status") != "succeeded":
            raise typer.Exit(1)
    finally:
        client.close()


@dev_app.command("suite-check")
def dev_suite_check(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE, suite: Annotated[str, typer.Option("--suite")] = "sql-function-set") -> None:
    from postgres_gym.core import data, registry
    issues = data.validate(registry.load(suite))
    if issues:
        raise ValueError("\n".join(issues))
    _show({"ok": True, "suite": suite, "source": str(source)})


@dev_app.command("verify")
def dev_verify(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE, suite: Annotated[str, typer.Option("--suite")] = "sql-function-set", task: Annotated[str, typer.Option("--task")] = "area") -> None:
    from postgres_gym import Gym
    _show(Gym(suite).verify(task))


@dev_app.command("selftest")
def dev_selftest(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE, suite: Annotated[str, typer.Option("--suite")] = "sql-function-set", task: Annotated[str, typer.Option("--task")] = "area") -> None:
    from postgres_gym import Gym
    _show({agent: Gym(suite).run(task, agent).record for agent in ("replay", "noop", "cheat", "probe")})


@dev_app.command("stand-fetch")
def dev_stand_fetch(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE) -> None:
    path = source.resolve() / "stand" / "pg.git"
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        operations.checked(["git", "clone", "--bare", os.environ.get("POSTGRES_GYM_PG_MIRROR", "https://git.postgresql.org/git/postgresql.git"), str(path)])
    operations.checked(["git", "--git-dir=" + str(path), "update-ref", "refs/postgres-gym/pristine", "aa14281fdde6b2cc7a794dd02bc128dd0cb20b45"])
    _show({"ok": True})


@dev_app.command("image")
def dev_image(source: Annotated[Path, typer.Option("--source")] = _DEFAULT_SOURCE) -> None:
    command = ["docker", "build", "-f", "deploy/task/Dockerfile", "-t", os.environ.get("POSTGRES_GYM_TASK_IMAGE", "postgres-gym-task:17.11")]
    operations.checked([*command, "."], cwd=source.resolve())
    _show({"ok": True})


def main(argv: list[str] | None = None) -> None:
    try:
        app(args=argv, prog_name="pg-gym") if argv is not None else app()
    except ApiError as exc:
        print(json.dumps({"error": {"code": exc.code, "message": str(exc)}}), file=sys.stderr)
        raise typer.Exit(3 if exc.status in {401, 403} else 2 if exc.status in {400, 422} else 1) from None
    except httpx.HTTPError as exc:
        print(json.dumps({"error": {"code": "network_error", "message": type(exc).__name__}}), file=sys.stderr)
        raise typer.Exit(4) from None
    except TimeoutError as exc:
        print(str(exc), file=sys.stderr)
        raise typer.Exit(124) from None
    except (ValueError, OSError, KeyError) as exc:
        print(str(exc), file=sys.stderr)
        raise typer.Exit(2) from None
    except KeyboardInterrupt:
        print("Client interrupted. Remote jobs continue; use pg-gym jobs cancel to stop one.", file=sys.stderr)
        raise typer.Exit(130) from None


if __name__ == "__main__":
    main()
