"""Unified Typer command line interface.

The command implementation lives in :mod:`postgres_gym_platform.cli_app` so
the library and hosted platform expose one consistent ``pg-gym`` executable.
"""

from __future__ import annotations

import getpass
import sys

from postgres_gym_platform.cli_app import app, main


def prompt_value(label: str, *, secret: bool = False) -> str:
    if not sys.stdin.isatty():
        raise ValueError(f"{label} is required in non-interactive mode")
    return getpass.getpass(label + ": ") if secret else input(label + ": ")


__all__ = ["app", "main", "prompt_value"]


if __name__ == "__main__":
    main()
