from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Any

from rich.console import Console


class OutputMode(str, Enum):
    table = "table"
    json = "json"
    jsonl = "jsonl"


@dataclass(frozen=True)
class CliContext:
    output: OutputMode = OutputMode.table
    no_color: bool = False


def emit(value: Any, context: CliContext, *, stream=None) -> None:
    stream = stream or sys.stdout
    if context.output is OutputMode.json:
        print(json.dumps(value, ensure_ascii=False, allow_nan=False), file=stream)
    elif context.output is OutputMode.jsonl:
        if isinstance(value, list):
            for item in value:
                print(json.dumps(item, ensure_ascii=False, allow_nan=False), file=stream)
        else:
            print(json.dumps(value, ensure_ascii=False, allow_nan=False), file=stream)
    else:
        Console(
            file=stream,
            no_color=context.no_color,
            force_terminal=False if not stream.isatty() else None,
        ).print_json(json.dumps(value, ensure_ascii=False, allow_nan=False))


def fail(message: str, code: int = 2) -> None:
    print(message, file=sys.stderr)
    raise SystemExit(code)
